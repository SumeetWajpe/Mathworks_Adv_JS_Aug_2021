// var listOfCourses = ["React","Angular","Node","Vue","Typescript"];
var listOfCourses = [
  {
    id: 1,
    title: "React",
    price: 5000,
    likes: 500,
    rating: 5,
    imageUrl:
      "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
  },
  {
    id: 2,
    title: "Angular",
    price: 4000,
    likes: 400,
    rating: 4,
    imageUrl:
      "https://bs-uploads.toptal.io/blackfish-uploads/blog/post/seo/og_image_file/og_image/15991/top-18-most-common-angularjs-developer-mistakes-41f9ad303a51db70e4a5204e101e7414.png",
  },
  {
    id: 3,
    title: "Node",
    price: 6000,
    likes: 500,
    rating: 5,
    imageUrl:
      "https://buddy.works/guides/covers/test-nodejs-app/share-nodejs-logo.png",
  },
  {
    id: 4,
    title: "Vue",
    price: 4000,
    likes: 300,
    rating: 4,
    imageUrl:
      "https://segwitz.com/wp-content/uploads/2021/06/vuejs-development-malaysia.jpeg",
  },
  {
    id: 5,
    title: "Typescript",
    price: 4000,
    likes: 800,
    rating: 4,
    imageUrl:
      "https://pantheon.io/sites/default/files/field/image/TypeScriptImage.jpeg",
  },
];

function LoadCourses() {
  let theRow = document.querySelector(".row");
  for (const course of listOfCourses) {
    DisplayCourseItem(course, theRow);
  }
}
function DisplayCourseItem(course, theRow) {
  var divParent = document.createElement("div");
  divParent.className = "col-md-3 p-1";

  var divCard = document.createElement("div");
  divCard.className = "card";

  // img
  var imgCard = document.createElement("img");
  imgCard.src = course.imageUrl;
  imgCard.className = "card-img-top";

  //rating
  var iRating;
  var pRating = document.createElement("p");
  for (let index = 0; index < course.rating; index++) {
    pRating.style.color = "Orange";
    iRating = document.createElement("i");
    iRating.classList.add("fas");
    iRating.classList.add("fa-star");
    pRating.appendChild(iRating);
  }

  // title
  var headingCardTitle = document.createElement("h5");
  headingCardTitle.innerText = course.title;
  headingCardTitle.className = "card-title";

  //price
  var divCardPrice = document.createElement("div");
  divCardPrice.innerText = "₹. " + course.price;
  divCardPrice.className = "card-text";

  // actions
  var btnLike = document.createElement("button");
  btnLike.className = "btn btn-primary btn-sm";

  btnLike.addEventListener("click", function () {
    course.likes += 1;
    this.children[1].innerText = course.likes;
  });

  var iLike = document.createElement("i");
  iLike.classList.add("far");
  iLike.classList.add("fa-thumbs-up");
  btnLike.appendChild(iLike);

  var spanLike = document.createElement("span");
  spanLike.innerText = course.likes;
  btnLike.appendChild(spanLike);

  //card body
  var divCardBody = document.createElement("div");
  divCardBody.className = "card-body";
  divCardBody.appendChild(headingCardTitle);
  divCardBody.appendChild(pRating);
  divCardBody.appendChild(divCardPrice);
  divCardBody.appendChild(btnLike);

  divCard.appendChild(imgCard);
  divCard.appendChild(divCardBody);

  divParent.appendChild(divCard);

  theRow.appendChild(divParent);
}
