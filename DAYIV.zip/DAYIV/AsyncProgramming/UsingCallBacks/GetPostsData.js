function GetPostsData(callBack) {
  var xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.onreadystatechange = function () {
    if (xmlHttpReq.status === 200 && xmlHttpReq.readyState === 4) {
      callBack(null, xmlHttpReq.responseText);
      //return xmlHttpReq.responseText;
    } else if (xmlHttpReq.status !== 200 && xmlHttpReq.readyState === 4) {
      callBack(xmlHttpReq.status, null);
    }
  };
  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlHttpReq.send(); // async call !
}
