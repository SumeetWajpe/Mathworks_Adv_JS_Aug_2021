function GetPostsData() {
  return new Promise((resolve, reject) => {
    var xmlHttpReq = new XMLHttpRequest();
    xmlHttpReq.onreadystatechange = function () {
      if (xmlHttpReq.status === 200 && xmlHttpReq.readyState === 4) {
        resolve(xmlHttpReq.responseText);
        //return xmlHttpReq.responseText;
      } else if (xmlHttpReq.status !== 200 && xmlHttpReq.readyState === 4) {
        reject(xmlHttpReq.status);
      }
    };
    xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlHttpReq.send(); // async call !
  });
}
