const http = require("http");
const fs = require("fs");

const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  console.log(req.url);
  if (req.url === "/") {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    // readTheFile
    // when all contents are read then send the response
    fs.readFile("Index.html", function (err, dataFromTheFile) {
      if (dataFromTheFile) {
        res.end(dataFromTheFile);
      }
    });
  } else if (req.url === "/styles.css") {
    fs.readFile("styles.css", function (err, dataFromTheFile) {
      if (dataFromTheFile) {
        res.end(dataFromTheFile);
      }
    });
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

console.log("Program Ended !");
