function PrintMsg(){
    console.log('Message from an external .js file !')
}