import Pie from './MathModule.js'
console.log(`PI is : ${Pie}`);

//  Import all
// import * as M from './MathModule.js';
// console.log(`Addition is : ${M.Add(20, 30)}`);
// console.log(`Product is : ${M.Multiply(20, 30)}`);
// console.log(`PI is : ${M.PI}`);

// Using Named Exports/Imports
// import {Add,Multiply} from './MathModule.js'
// console.log(`Addition is : ${Add(20, 30)}`);
// console.log(`Product is : ${Multiply(20, 30)}`);
