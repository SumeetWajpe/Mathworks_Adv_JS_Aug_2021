const express = require("express");
const router = express.Router();

router.route("/products").get((req, res) => {
  var products = [
    { id: 1, name: "LED TV", price: 50000 },
    { id: 2, name: "LCD TV", price: 80000 },
    { id: 3, name: "Laptop", price: 70000 },
  ];
  res.json(products);
});

module.exports = router;
