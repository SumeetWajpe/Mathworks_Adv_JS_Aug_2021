let express = require("express");
let path = require("path");
const productsRoutes = require("./routes");
var app = express();
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", productsRoutes);
app.get("/", (req, res) => {
  //   res.send("<h1> Hello  Express ! </h1>");
  res.sendFile("Index.html", { root: __dirname });
});

// 404 !
app.use((req, res) => {
  res.send("<h1 style='color:red'> Resource Not Found </h1>");
});
app.listen(5000, () => console.log("Server running at port 5000 !"));
