// var listOfCourses = ["React","Angular","Node","Vue","Typescript"];

async function LoadCourses() {
  try {
    let response = await fetch("http://localhost:5000/api/courses");
    let listOfCourses = await response.json();
    let theRow = document.querySelector(".row");
    for (const course of listOfCourses) {
      DisplayCourseItem(course, theRow);
    }
  } catch (error) {
    console.log(error);
  }
}
function DisplayCourseItem(course, theRow) {
  var divParent = document.createElement("div");
  divParent.className = "col-md-3 p-1";

  var divCard = document.createElement("div");
  divCard.className = "card";

  // img
  var imgCard = document.createElement("img");
  imgCard.src = course.imageUrl;
  imgCard.className = "card-img-top";

  //rating
  var iRating;
  var pRating = document.createElement("p");
  for (let index = 0; index < course.rating; index++) {
    pRating.style.color = "Orange";
    iRating = document.createElement("i");
    iRating.classList.add("fas");
    iRating.classList.add("fa-star");
    pRating.appendChild(iRating);
  }

  // title
  var headingCardTitle = document.createElement("h5");
  headingCardTitle.innerText = course.title;
  headingCardTitle.className = "card-title";

  //price
  var divCardPrice = document.createElement("div");
  divCardPrice.innerText = "₹. " + course.price;
  divCardPrice.className = "card-text";

  // actions
  var btnLike = document.createElement("button");
  btnLike.className = "btn btn-primary btn-sm";

  btnLike.addEventListener("click", function () {
    course.likes += 1;
    this.children[1].innerText = course.likes;
  });

  var iLike = document.createElement("i");
  iLike.classList.add("far");
  iLike.classList.add("fa-thumbs-up");
  btnLike.appendChild(iLike);

  var spanLike = document.createElement("span");
  spanLike.innerText = course.likes;
  btnLike.appendChild(spanLike);

  //card body
  var divCardBody = document.createElement("div");
  divCardBody.className = "card-body";
  divCardBody.appendChild(headingCardTitle);
  divCardBody.appendChild(pRating);
  divCardBody.appendChild(divCardPrice);
  divCardBody.appendChild(btnLike);

  divCard.appendChild(imgCard);
  divCard.appendChild(divCardBody);

  divParent.appendChild(divCard);

  theRow.appendChild(divParent);
}
