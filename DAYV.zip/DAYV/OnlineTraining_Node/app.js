let express = require("express");
let path = require("path");
var cors = require("cors");
const coursesRoutes = require("./coursesroutes");

var app = express();

app.use(cors());
app.use(express.static(path.join(__dirname, "public")));

app.use("/api", coursesRoutes);

app.get("/", (req, res) => {
  //   res.send("<h1> Hello  Express ! </h1>");
  res.sendFile("Index.html", { root: __dirname + "/public" });
});

// 404 !
app.use((req, res) => {
  res.send("<h1 style='color:red'> Resource Not Found </h1>");
});
app.listen(5000, () => console.log("Server running at port 5000 !"));
